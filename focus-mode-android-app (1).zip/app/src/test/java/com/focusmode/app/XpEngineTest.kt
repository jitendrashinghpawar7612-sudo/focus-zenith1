package com.focusmode.app

import com.focusmode.app.gamification.XpEngine
import org.junit.Assert.assertEquals
import org.junit.Test

class XpEngineTest {

    @Test
    fun testLevelCalculationAtZeroXp() {
        val result = XpEngine.calculateLevel(0)
        assertEquals(1, result.level)
        assertEquals(0, result.currentLevelBaseXp)
        assertEquals(50, result.nextLevelXp)
        assertEquals(0, result.progressPercent)
        assertEquals(50, result.xpRemaining)
    }

    @Test
    fun testLevelCalculationAtThreshold() {
        val level2 = XpEngine.calculateLevel(50)
        assertEquals(2, level2.level)
        assertEquals(50, level2.currentLevelBaseXp)
        assertEquals(200, level2.nextLevelXp)
        assertEquals(0, level2.progressPercent)

        val level3 = XpEngine.calculateLevel(200)
        assertEquals(3, level3.level)
        assertEquals(200, level3.currentLevelBaseXp)
        assertEquals(450, level3.nextLevelXp)
    }

    @Test
    fun testDeterministicXpRewards() {
        assertEquals(25, XpEngine.XP_STUDY_SESSION_25M)
        assertEquals(40, XpEngine.XP_CREATION_SESSION_40M)
        assertEquals(15, XpEngine.XP_URGE_CONTROL_10M)
    }
}
