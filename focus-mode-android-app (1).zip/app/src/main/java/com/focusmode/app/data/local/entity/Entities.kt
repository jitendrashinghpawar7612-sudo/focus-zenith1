package com.focusmode.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "study", "creation", "urge"
    val durationMinutes: Int,
    val elapsedSeconds: Int,
    val completed: Boolean,
    val timestamp: Long,
    val xpEarned: Int
)

@Entity(tableName = "app_limits")
data class AppLimitEntity(
    @PrimaryKey val packageName: String,
    val limitMinutes: Int = 30,
    val warned80PercentToday: Boolean = false,
    val warned100PercentToday: Boolean = false,
    val lastResetDay: String
)

@Entity(tableName = "reels_counter")
data class ReelsCounterEntity(
    @PrimaryKey val id: String, // "com.instagram.android_2026-10-25"
    val packageName: String,
    val dateString: String,
    val manualCount: Int
)

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val frequency: String,
    val category: String,
    val createdTimestamp: Long,
    val currentStreak: Int
)

@Entity(tableName = "habit_completions")
data class HabitCompletionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val dateString: String // "YYYY-MM-DD"
)

@Entity(tableName = "water_logs")
data class WaterLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val amountMl: Int,
    val dateString: String
)

@Entity(tableName = "exercise_logs")
data class ExerciseLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val durationMinutes: Int,
    val activityType: String,
    val intensity: String
)

@Entity(tableName = "sleep_logs")
data class SleepLogEntity(
    @PrimaryKey val dateString: String,
    val durationHours: Float,
    val qualityRating: Int
)

@Entity(tableName = "weight_logs")
data class WeightLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val weightKg: Float
)
