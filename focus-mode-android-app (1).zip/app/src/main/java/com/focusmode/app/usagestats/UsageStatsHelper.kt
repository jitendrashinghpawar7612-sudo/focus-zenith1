package com.focusmode.app.usagestats

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import java.util.Calendar

data class TrackedPackageUsage(
    val packageName: String,
    val displayName: String,
    val totalTimeInForegroundMillis: Long,
    val lastTimeUsedMillis: Long,
    val localDayStartMillis: Long,
    val localDayEndMillis: Long
)

object UsageStatsHelper {

    val TARGET_PACKAGES = mapOf(
        "com.google.android.youtube" to "YouTube",
        "com.instagram.android" to "Instagram",
        "com.facebook.katana" to "Facebook"
    )

    /**
     * Checks if PACKAGE_USAGE_STATS permission has been granted by user in System Settings.
     */
    fun hasUsageAccessPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Creates an Intent to navigate directly to the system Usage Access settings screen.
     */
    fun createUsageAccessIntent(): Intent {
        return Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
    }

    /**
     * Computes start and end timestamps for the current local calendar day (00:00:00.000 to now).
     */
    fun getLocalDayWindow(): Pair<Long, Long> {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfDay = calendar.timeInMillis
        val now = System.currentTimeMillis()
        return Pair(startOfDay, now)
    }

    /**
     * Queries UsageStatsManager for daily foreground usage of target apps within local day window.
     */
    fun queryDailyUsage(context: Context): List<TrackedPackageUsage> {
        if (!hasUsageAccessPermission(context)) {
            return emptyList()
        }

        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val (startTime, endTime) = getLocalDayWindow()

        val usageStatsList: List<UsageStats> = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            startTime,
            endTime
        ) ?: emptyList()

        // Aggregate by package in case multiple buckets are returned for the local interval
        val aggregatedTime = mutableMapOf<String, Long>()
        val latestUseTime = mutableMapOf<String, Long>()

        for (stats in usageStatsList) {
            val pkg = stats.packageName
            if (TARGET_PACKAGES.containsKey(pkg)) {
                val currentTotal = aggregatedTime.getOrDefault(pkg, 0L)
                aggregatedTime[pkg] = currentTotal + stats.totalTimeInForeground

                val existingLastUsed = latestUseTime.getOrDefault(pkg, 0L)
                if (stats.lastTimeUsed > existingLastUsed) {
                    latestUseTime[pkg] = stats.lastTimeUsed
                }
            }
        }

        return TARGET_PACKAGES.map { (pkgName, displayName) ->
            TrackedPackageUsage(
                packageName = pkgName,
                displayName = displayName,
                totalTimeInForegroundMillis = aggregatedTime.getOrDefault(pkgName, 0L),
                lastTimeUsedMillis = latestUseTime.getOrDefault(pkgName, 0L),
                localDayStartMillis = startTime,
                localDayEndMillis = endTime
            )
        }
    }
}
