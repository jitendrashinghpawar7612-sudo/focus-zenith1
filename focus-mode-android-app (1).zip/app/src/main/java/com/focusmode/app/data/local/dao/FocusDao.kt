package com.focusmode.app.data.local.dao

import androidx.room.*
import com.focusmode.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusDao {
    @Insert
    suspend fun insertSession(session: FocusSessionEntity): Long

    @Query("SELECT * FROM focus_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<FocusSessionEntity>>

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE type = :type AND completed = 1")
    suspend fun getCompletedSessionCount(type: String): Int

    // App Limits
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAppLimit(limit: AppLimitEntity)

    @Query("SELECT * FROM app_limits")
    fun getAllLimits(): Flow<List<AppLimitEntity>>

    @Query("SELECT * FROM app_limits WHERE packageName = :packageName")
    suspend fun getLimitForPackage(packageName: String): AppLimitEntity?

    // Manual Reels Counter
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReelsCount(counter: ReelsCounterEntity)

    @Query("SELECT * FROM reels_counter WHERE packageName = :packageName AND dateString = :dateString")
    suspend fun getReelsCount(packageName: String, dateString: String): ReelsCounterEntity?

    // Habits
    @Insert
    suspend fun insertHabit(habit: HabitEntity): Long

    @Query("SELECT * FROM habits")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertHabitCompletion(completion: HabitCompletionEntity)

    @Query("SELECT * FROM habit_completions WHERE dateString = :dateString")
    fun getCompletionsForDate(dateString: String): Flow<List<HabitCompletionEntity>>

    // Health logs
    @Insert
    suspend fun insertWater(log: WaterLogEntity)

    @Query("SELECT SUM(amountMl) FROM water_logs WHERE dateString = :dateString")
    fun getDailyWaterSum(dateString: String): Flow<Int?>

    @Insert
    suspend fun insertExercise(log: ExerciseLogEntity)

    @Query("SELECT * FROM exercise_logs ORDER BY timestamp DESC")
    fun getExerciseLogs(): Flow<List<ExerciseLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSleep(log: SleepLogEntity)

    @Query("SELECT * FROM sleep_logs WHERE dateString = :dateString")
    suspend fun getSleepForDate(dateString: String): SleepLogEntity?

    @Insert
    suspend fun insertWeight(log: WeightLogEntity)

    @Query("SELECT * FROM weight_logs ORDER BY timestamp DESC LIMIT 30")
    fun getWeightLogs(): Flow<List<WeightLogEntity>>
}
