package com.focusmode.app.service

import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.focusmode.app.FocusModeApp
import com.focusmode.app.R
import com.focusmode.app.usagestats.UsageStatsHelper

/**
 * Background WorkManager periodic worker.
 * Checks foreground usage against 80% and 100% daily limits.
 * Honest disclosure: Android OS WorkManager enforces minimum 15-minute execution intervals.
 * It is subject to device Doze mode and manufacturer battery optimizations.
 * FOCUS MODE does NOT block packages or inject intrusive overlay blockers.
 */
class UsageMonitoringWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!UsageStatsHelper.hasUsageAccessPermission(context)) {
            return Result.success()
        }

        val usageList = UsageStatsHelper.queryDailyUsage(context)
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Default limit is 30 minutes (1,800,000 ms)
        val limitMillis = 30 * 60 * 1000L
        val warning80Millis = (limitMillis * 0.8).toLong() // 24 minutes

        for (item in usageList) {
            val usedMillis = item.totalTimeInForegroundMillis
            val usedMinutes = usedMillis / (60 * 1000)

            if (usedMillis >= limitMillis) {
                // 100% limit warning
                val notification = NotificationCompat.Builder(context, FocusModeApp.CHANNEL_USAGE_LIMITS)
                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle("${item.displayName}: 100% Limit Reached")
                    .setContentText("You have used ${item.displayName} for ${usedMinutes}m today (30m limit).")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .build()

                notificationManager.notify(item.packageName.hashCode() + 100, notification)
            } else if (usedMillis >= warning80Millis) {
                // 80% warning
                val notification = NotificationCompat.Builder(context, FocusModeApp.CHANNEL_USAGE_LIMITS)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("${item.displayName}: 80% Daily Limit Approaching")
                    .setContentText("Used ${usedMinutes}m of 30m limit. 6 minutes remaining.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()

                notificationManager.notify(item.packageName.hashCode() + 80, notification)
            }
        }

        return Result.success()
    }
}
