package com.focusmode.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.focusmode.app.data.local.FocusDatabase
import com.focusmode.app.data.datastore.UserPreferencesRepository
import com.focusmode.app.service.UsageMonitoringWorker
import java.util.concurrent.TimeUnit

class FocusModeApp : Application() {

    lateinit var database: FocusDatabase
        private set

    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = FocusDatabase.getDatabase(this)
        preferencesRepository = UserPreferencesRepository(this)

        createNotificationChannels()
        scheduleUsageMonitoringWorker()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Warning Notification Channel (80% and 100% daily limit alerts)
            val warningChannel = NotificationChannel(
                CHANNEL_USAGE_LIMITS,
                "Usage Limit Warnings",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when tracked social apps reach 80% or 100% of your daily limit"
                enableVibration(true)
            }

            // Foreground Timer Channel
            val timerChannel = NotificationChannel(
                CHANNEL_FOCUS_TIMER,
                "Active Focus Sessions",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays running study, creation, or urge-control countdown"
            }

            notificationManager.createNotificationChannel(warningChannel)
            notificationManager.createNotificationChannel(timerChannel)
        }
    }

    private fun scheduleUsageMonitoringWorker() {
        // Periodic check every 15 minutes (minimum WorkManager interval)
        // Honest disclosure: WorkManager runs subject to Android Doze and OS battery batching
        val workRequest = PeriodicWorkRequestBuilder<UsageMonitoringWorker>(
            15, TimeUnit.MINUTES
        ).build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "usage_limit_check",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }

    companion object {
        const val CHANNEL_USAGE_LIMITS = "channel_usage_limits"
        const val CHANNEL_FOCUS_TIMER = "channel_focus_timer"

        lateinit var instance: FocusModeApp
            private set
    }
}
