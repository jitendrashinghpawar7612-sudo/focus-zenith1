package com.focusmode.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Premium dark charcoal surfaces with balanced Green, Blue, Red, Pink palette
val CharcoalBackground = Color(0xFF101015)
val CharcoalSurface = Color(0xFF1A1A22)
val CharcoalElevated = Color(0xFF242430)
val CharcoalBorder = Color(0xFF2E2E3C)

// Intentional Color Palette
val GreenHabits = Color(0xFF10B981)      // Progress, completed tasks, healthy habits
val BlueFocus = Color(0xFF3B82F6)        // Focus timer, study sessions, screen-time tracking
val RedLimits = Color(0xFFEF4444)        // Screen-time warnings and limits
val PinkAccent = Color(0xFFEC4899)       // Achievements, selected highlights, accents

val TextPrimary = Color(0xFFF1F1F5)
val TextSecondary = Color(0xFF9E9EA8)
val TextMuted = Color(0xFF6C6C78)

private val DarkColorScheme = darkColorScheme(
    primary = BlueFocus,
    onPrimary = Color.White,
    primaryContainer = CharcoalElevated,
    onPrimaryContainer = BlueFocus,
    secondary = PinkAccent,
    tertiary = GreenHabits,
    error = RedLimits,
    background = CharcoalBackground,
    surface = CharcoalSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalElevated,
    outline = CharcoalBorder
)

@Composable
fun FocusModeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
