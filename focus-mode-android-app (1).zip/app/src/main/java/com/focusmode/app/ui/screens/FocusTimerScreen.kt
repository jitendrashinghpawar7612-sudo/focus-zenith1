package com.focusmode.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.ui.theme.*

@Composable
fun FocusTimerScreen(
    isActive: Boolean,
    progressPercent: Int,
    remainingMinutes: Int,
    remainingSeconds: Int,
    onTogglePlay: () -> Unit,
    onReset: () -> Unit
) {
    // Dynamic pulse duration based on session progress (accelerates near completion)
    val pulseDurationMs = when {
        !isActive -> 4500
        progressPercent >= 90 -> 850    // Final Sprint
        progressPercent >= 70 -> 1400   // Peak Momentum
        progressPercent >= 40 -> 2200   // Deep Work
        else -> 3400                    // Calm Focus
    }

    val infiniteTransition = rememberInfiniteTransition(label = "BreathingPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isActive) (if (progressPercent >= 90) 1.06f else 1.03f) else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = pulseDurationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = if (isActive) (if (progressPercent >= 90) 0.85f else 0.5f) else 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = pulseDurationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseAlpha"
    )

    val pulseColor = if (progressPercent >= 90) PinkAccent else BlueFocus

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Breathing pulse radial dial
        Box(
            modifier = Modifier.size(240.dp),
            contentAlignment = Alignment.Center
        ) {
            // Animated breathing aura ring
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .scale(pulseScale)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(pulseColor.copy(alpha = pulseAlpha), Color.Transparent)
                        ),
                        shape = CircleShape
                    )
            )

            // Canvas circular arc
            Canvas(modifier = Modifier.size(190.dp)) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.06f),
                    style = Stroke(width = 12.dp.toPx())
                )
                drawArc(
                    brush = Brush.sweepGradient(listOf(BlueFocus, pulseColor)),
                    startAngle = -90f,
                    sweepAngle = 360f * (progressPercent / 100f),
                    useCenter = false,
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Central countdown digits
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = String.format("%02d:%02d", remainingMinutes, remainingSeconds),
                    color = TextPrimary,
                    fontSize = 38.sp
                )
                Text(
                    text = "$progressPercent% elapsed",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}
