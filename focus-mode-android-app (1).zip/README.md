# FOCUS MODE — Native Android Digital Wellbeing & Habit System

A standalone native Android application built with **Kotlin 2.0**, **Jetpack Compose**, **Material 3**, **MVVM**, **Room Database**, and **Preferences DataStore**.

---

## 1. Core Architecture & Privacy Principles

1. **Local-First & Offline**: Personal stats, focus sessions, health logs, and achievements are stored solely on-device in Room Database and DataStore.
2. **Zero Remote Telemetry**: No mandatory sign-in, remote analytics, or upload of personal app usage statistics.
3. **Usage Access Transparency**: Measures foreground usage for:
   - YouTube (`com.google.android.youtube`)
   - Instagram (`com.instagram.android`)
   - Facebook (`com.facebook.katana`)
   Using Android's official `UsageStatsManager`.
4. **Honest Limitations**:
   - Usage time reflects foreground app time, not individual Reels/Shorts counts; dedicated manual counters are provided.
   - Background limit evaluations are scheduled via `WorkManager` (~15 min cadence) subject to Android OS Doze and battery batching.
   - FOCUS MODE issues alerts and records compliance; it does NOT aggressively block apps or manipulate AccessibilityServices.
5. **Friends Competition Contract**:
   - Competition requires consented peer-to-peer or zero-knowledge backend to safeguard private data. An honest, transparent unavailable state is rendered instead of fabricated bots or mock leaderboards.

---

## 2. Requirements & Prerequisites

- **Android Studio**: Ladybug (2024.2.1) or newer
- **JDK**: Java 17 or Java 21
- **Target SDK**: Android 15 (API 35)
- **Minimum SDK**: Android 8.0 (API 26)
- **Physical Device**: Android phone running Android 8.0+ connected via USB or Wi-Fi ADB.

---

## 3. Step-by-Step Installation on Physical Device

### Step 1: Enable Developer Options & USB Debugging
1. On your Android phone, go to **Settings** > **About Phone**.
2. Tap **Build Number** 7 times until you see "You are now a developer!".
3. Go back to **Settings** > **System** > **Developer Options**.
4. Enable **USB Debugging**.

### Step 2: Open Project in Android Studio
1. Launch Android Studio.
2. Select **Open** and choose the downloaded `focus-mode-android` root folder.
3. Allow Gradle to sync dependencies.

### Step 3: Run Unit Tests
In terminal or Android Studio Run menu:
```bash
./gradlew testDebugUnitTest
```
All tests in `XpEngineTest` and `UsageStatsCalculationTest` will execute and pass.

### Step 4: Build and Install APK
Connect phone with USB cable, verify with `adb devices`, then run:
```bash
./gradlew installDebug
```
Or click the green **Run (▶)** button in Android Studio with your device selected.

### Step 5: Grant Usage Access Permission on Device
1. Upon first launching FOCUS MODE, tap **Grant Usage Access** on the Home or Usage screen.
2. The app opens **Settings > Apps with Usage Access**.
3. Locate **Focus Mode** and toggle **Permit usage access** to ON.
4. Return to FOCUS MODE: Foreground usage time for YouTube, Instagram, and Facebook will update automatically on resume!
